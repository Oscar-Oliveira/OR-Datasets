Description: 
2D Irregular test problem (MAO) from BOUNSAYTHIP/MAOUCHE (1997)
Data set from textile industry, scanned from sample layout in paper Bounsaythip and Maouche (1997) by Eva Hopper. Approximated by polygons
(Data sets: mao)

References: 
Bounsaythip, C. and Maouche, S. 1997, Irregular Shape Nesting and Placing with Evolutionary Approach, 
In: Proceedings of the IEEE International Conference On Systems, Man and Cybernetics, vol. 4, pp. 3425-3430. 