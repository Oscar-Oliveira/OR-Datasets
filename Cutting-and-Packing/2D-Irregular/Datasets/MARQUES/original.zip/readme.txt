Description: 
2D Irregular test problem (MARQUES) from MARQUES/BISPO/SENTIEIRO 1991
Data set from textile industry, scanned from sample layout in paper Marques et al (1991) by Eva Hopper. Approximated by polygons
(Data sets: marques)

References: 
Marques, V.M.M., Bispo, C.F.G. and Sentieiro, J.J.S. 1991, A system for the compaction of two-dimensional irregular shapes based 
on simulated annelaing. Proceedings of the 1991 International Conference On Industrial Electronics, 
Control and Instrumentation - IECON'91, Kobe, Japan, Oct. 1991, 99. 1911-1916. 