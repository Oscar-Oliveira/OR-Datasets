Description: 
2D Irregular data set (SHIRTS) from OLIVEIRA/GOMES/FERREIRA (2000)
Data set from textile industry. Instance used in Dowsland et al (1998) and supplied by the authors.
(Data sets: shirts)

References: 
Oliveira, J.F., Gomes, A.M. and Ferreira, J.S., A new constructive algorithm for nesting prolems, OR Spektrum (2000) 22: 263-284.
Dowsland, K.A., Dowsland, W.B., Bennel, J.A. (1998), Jostling for position: Local improvement for irregular cutting patterns, 
Journal of the Operational Research Society 49:647-658.