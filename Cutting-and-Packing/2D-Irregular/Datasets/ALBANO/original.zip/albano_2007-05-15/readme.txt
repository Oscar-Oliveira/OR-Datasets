Description: 
Irregular test problem (ALBANO) from ALBANO/SAPPUPO (1980)
Data set from textile industry, scanned from sample layout in paper Albano and Sappupo (1980) by Eva Hopper. Approximated by polygons.
(Data sets: albano)

References: 
Albano, A. and Sappupo, G., 1980, Optimal allocation of two-dimensional irregular shapes using heuristic search methods. 
IEEE Transactions on Systems, Man and Cybernetics, SMC-10, 242-248.