Description: 
2D Irregular test problem (DAGLI) by HOPPER
Data set from textile industry, scanned from sample layout in paper Ratanapan and Dagli (1997)
(Data sets: dagli)

References: 
Ratanapan, K. and Dagli, C.H. 1997, An object-based evolutionary algorithm for solving irregular nesting problems. 
In: Proceedings for Artificial Neural Networks in Engineering Conference (ANNIE'97), vol.7, ASME Press, New York, pp. 383-388.