Description: 
2D Irregular data set (TROUSERS) from OLIVEIRA/GOMES/FERREIRA (2000)
Data set from textile industry.
(Data sets: trousers)

References: 
Oliveira, J.F., Gomes, A.M. and Ferreira, J.S., A new constructive algorithm for nesting prolems, OR Spektrum (2000) 22: 263-284.